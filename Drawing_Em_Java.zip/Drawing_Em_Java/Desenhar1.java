
package IsauraM.Bola;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author isaura Manico
 */


public class Desenhar1 extends JPanel implements Runnable
{
    
     private Thread thread = new Thread(this);
    
      private Bola bola = new Bola(1,700,100,100);
     
     
     public Desenhar1()
     {
        JFrame frame = new JFrame();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);
        
        frame.setSize(1020,900);
        
      
        frame.setVisible(true);
        
        //Iniciando uma thread
        thread.start();
     }

   
    //Aonde tudo acontece!
    public void atualizar()
    {
        
      if(bola.getPosx()>= getWidth()-bola.getLargura())
        {
           // terra.setPosx(terra.getPosx()-1);
           // bola.setPosx(bola.getPosx()+bola.getDirx());
            bola.setDirx(bola.getDirx()*(-1));
             
                                                        //movimento da esquerda para direta somente em xx
        }
        else if(bola.getPosx()<=0)
        {
              bola.setDirx(bola.getDirx()*(-1));
             
        }
         
          bola.setPosx(bola.getPosx()+bola.getDirx()); //da esquerda para direita e vice-versa
       
       
          
             
        
        
        
    }
    
    public void dormir() 
    {
         try 
         {
             Thread.sleep(9);
         } 
         catch (InterruptedException ex) 
         {
             System.out.println("Error");
         }
    }
    

   
     @Override
    public void run()
    {
       // System.out.println("Prim");
       // System.out.println(""+terra.getAltura());
        
        //Velocidade 
        
        //Execucao  Infinita
        while(true)
        {
            atualizar();
            repaint();
            dormir();
        }
       
    }
    
    public void paintComponent( Graphics g )        
    {
        
         super.paintComponent(g);//Faz referencia superclasse, limpa a execucao do metodo  anterior
         
         
        Graphics2D g2d = (Graphics2D)g;
        
        g2d.setColor(Color.red);
        
        g2d.fillOval(bola.getPosx(), bola.getPosy(), bola.getAltura(), bola.getLargura());
        
        
        
       
         
         
       
       
    }
    
    
}
