
package IsauraM.Bola;

/**
 *
 * @author isaura
 */
public class PrincDesenhar1 
{
    public static void main(String[] args)
    {
        new Desenhar1();
    }
    
}
