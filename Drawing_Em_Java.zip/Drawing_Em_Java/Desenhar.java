
package IsauraM.Bola;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author isaura
 */
public class Desenhar extends JPanel implements Runnable
{
    
     private Thread thread = new Thread(this);
     //private Bola bola = new Bola(600,350,100,100);
     //private Bola bola = new Bola(0,10,100,100);
     
      
     
      private Bola bola = new Bola(0,100,100,100);
      
    
     
     
     public Desenhar()
     {
        JFrame frame = new JFrame();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);
        
        frame.setSize(1020,900);
        
       // frame.setLayout(null);
        frame.setVisible(true);
        
        thread.start();
     }

   
    
    public void atualizar()
    {
    
         //movimento somente no eixo dos yy
        
        //movimento de cima yy de cima para baixo
          if(bola.getPosy()<=0 )
       // else if(bola.getPosy()<=getHeight()/bola.getAltura())
        {
            bola.setDiry(bola.getDiry()*(-1));
          
        }
            //movimento yy de baixo para cima
        if(bola.getPosy() >= getHeight()-bola.getAltura())
        {
            if(getHeight()/2 >= bola.getAltura())
            {
                bola.setDiry(bola.getDiry()*(-1));
              
              
                
            }
               
           
        }
          
        
        
      
          bola.atualizar();
          
          
             
        
        
        
    }
    
    public void dormir() 
    {
         try 
         {
             Thread.sleep(9);
         } 
         catch (InterruptedException ex) 
         {
             System.out.println("Error");
         }
    }
    

   
     @Override
    public void run()
    {
        while(true)
        {
            atualizar();
            repaint();
            dormir();
        }
       
    }
    
    public void paintComponent( Graphics g )        
    {
       super.paintComponent(g);
       //Graphics2D g2 = (Graphics2D)g;
         g.setColor(Color.red);
         g.fillOval(bola.getPosx(), bola.getPosy(), bola.getAltura(), bola.getLargura());
       
       
    }
    
    
}
