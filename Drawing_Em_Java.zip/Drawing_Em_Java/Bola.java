
package IsauraM.Bola;

/**
 *
 * @author isaura
 */
public class Bola 
{
    
    private int posx,posy,largura,altura;
    
    ///velocidades
     int dirx= 3; 
     int diry =3;
    
  
    
    public Bola( int posx,int posy,int largura,int altura)
    {
        this.posx = posx;
        this.posy = posy;
        this.largura = largura;
        this.altura = altura;
    }

    public int getPosx() 
    {
        return posx;
    }

    public void setPosx(int posx)
    {
        this.posx = posx;
    }

    public int getPosy() 
    {
        return posy;
    }

    public void setPosy(int posy) 
    {
        this.posy = posy;
    }

    public int getLargura()
    {
        return largura;
    }

    public void setLargura(int largura)
    {
        this.largura = largura;
    }

    public int getAltura() 
    {
        return altura;
    }

    public void setAltura(int altura) 
    {
        this.altura = altura;
    }

    public int getDirx() 
    {
        return dirx;
    }

    public void setDirx(int dirx)
    {
        this.dirx = dirx;
    }

    public int getDiry() 
    {
        return diry;
    }

    public void setDiry(int diry)
    {
        this.diry = diry;
    }
    
    
    //Metodo responsavel por adicionar velocidade
    public  void atualizar()
    {
        //this.posx += dirx;
        this.posy += diry;
    }
    
    
    
}
